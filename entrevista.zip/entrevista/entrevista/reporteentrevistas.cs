﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace entrevista
{
    public partial class reporteentrevistas : Form
    {

        //Se hace la conexion con la base de datos
        SqlConnection con;

        void Conexion()
        {
            try
            {
                con = new SqlConnection(@"server=DESKTOP-75A4S5V\SQLEXPRESS ; database=master ; integrated security = true");

                con.Open();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Se carga el reporte de las entrevistas
        void cargar()
        {
            try
            {
                string query = "SELECT * FROM entrevista";
                SqlCommand consultacmd = new SqlCommand(query, con);
                SqlDataAdapter adap = new SqlDataAdapter();
                adap.SelectCommand = consultacmd;
                DataTable dtable = new DataTable();
                adap.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }

        }
        public reporteentrevistas()
        {
            InitializeComponent();

            Conexion();

            cargar();
        }
        //Para mostrar en el campo de Notas el contenido que se guardo en la bd
        void cargareditar()
        {
            string query = "SELECT notas FROM entrevista where id = '" + txtID.Text + "'";
            SqlCommand consultacmd = new SqlCommand(query, con);
            SqlDataReader leer;
            leer = consultacmd.ExecuteReader();
            try
            {
                while (leer.Read())
                {
                    txtNotas.Text = leer["notas"].ToString();
                    

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            leer.Close();

        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            cargareditar();

        }
        //Despues de validar que no este vacio se elimina el elemento seleccionado
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            try
            {
              
                if (txtID.Text == "")
                {
                    MessageBox.Show("Selecciona una opcion");
                }
                else
                {
                    string sql = @"DELETE FROM entrevista WHERE id= @id";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtID.Text));

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se borro correctamente");
                    cargar();
                    txtID.Text = "";
                   
                    
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //Despues de validar el campo guarda y actualiza la nota y el estatus de la entrevista
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "" || txtNotas.Text == "") {
                MessageBox.Show("No deje campos vacios");
            }
            else
            {
                bool reclutado = ckReclutado.Checked;
                string queryeditar = "update entrevista set notas='" + txtNotas.Text + "', reclutado='" + reclutado + "' WHERE id='" + txtID.Text + "'";
                SqlCommand cmdEditar = new SqlCommand(queryeditar, con);
                SqlDataReader leer;

                try
                {
                    leer = cmdEditar.ExecuteReader();
                    while (leer.Read()) { }
                    MessageBox.Show("Datos cargados");
                    leer.Close();
                    cargar();


                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Reporte este problema al correo: sistemas@orangexp.net " + ex.ToString());
                }
            }
        }
    }
}
