﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace entrevista
{
    public partial class vacante : Form
    {

        //Se hace la conexion con la BD
        SqlConnection con;

        void Conexion()
        {
            try
            {
                con = new SqlConnection(@"server=DESKTOP-75A4S5V\SQLEXPRESS ; database=master ; integrated security = true");

                con.Open();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Para generar automaticamente el id
        void vacanteid()
        {
            string query = "SELECT id from vacante";
            SqlCommand consultacmd = new SqlCommand(query, con);
            SqlDataReader leer;
            leer = consultacmd.ExecuteReader();
            try
            {
                while (leer.Read())
                {
                    label4.Text = leer["id"].ToString();

                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("No se encontro nada. " + "Reporte este problema al correo: sistemas@orangexp.net "
                    + ex.ToString());
            }

            leer.Close();
        }
        public vacante()
        {
            InitializeComponent();
            Conexion();
            vacanteid();
        }
        //Despues de validar se insertan los valores de la vacante en la tabla
        private void button1_Click(object sender, EventArgs e)
        {
            if(txtSueldo.Text=="")
            {
                MessageBox.Show("Este campo no puede estar vacio");
            }
            else
            {
                try
                {
                 
                    string agregar = "INSERT INTO Vacante (id, area, sueldo, activo) VALUES (@id, @area, @sueldo, @activo)";
                    SqlCommand com = new SqlCommand(agregar, con);

                    com.Parameters.AddWithValue("@id", Convert.ToInt32(label4.Text) + 1);
                    com.Parameters.AddWithValue("@area", txtArea.Text);
                    com.Parameters.AddWithValue("@sueldo", txtSueldo.Text);

                    if (ckActivo.Checked == true)
                    {
                        com.Parameters.AddWithValue("@activo", true);
                    }
                    else
                    {
                        com.Parameters.AddWithValue("@activo", false);
                    }

                    com.ExecuteNonQuery();
                    MessageBox.Show("Se guardó correctamente");
                    vacanteid();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }
        }
        //Para evitar que pongan letras en el campo de Sueldo
        private void txtSueldo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        //Para ver el reporte de las vacantes
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string query = "SELECT * FROM vacante";
                SqlCommand consultacmd = new SqlCommand(query, con);
                SqlDataAdapter adap = new SqlDataAdapter();
                adap.SelectCommand = consultacmd;
                DataTable dtable = new DataTable();
                adap.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }
    }
}
