﻿
namespace entrevista
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProspecto = new System.Windows.Forms.Button();
            this.btnVacante = new System.Windows.Forms.Button();
            this.btnEntrevista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnProspecto
            // 
            this.btnProspecto.Location = new System.Drawing.Point(12, 12);
            this.btnProspecto.Name = "btnProspecto";
            this.btnProspecto.Size = new System.Drawing.Size(394, 84);
            this.btnProspecto.TabIndex = 0;
            this.btnProspecto.Text = "Prospecto";
            this.btnProspecto.UseVisualStyleBackColor = true;
            this.btnProspecto.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnVacante
            // 
            this.btnVacante.Location = new System.Drawing.Point(13, 103);
            this.btnVacante.Name = "btnVacante";
            this.btnVacante.Size = new System.Drawing.Size(393, 87);
            this.btnVacante.TabIndex = 1;
            this.btnVacante.Text = "Vacante";
            this.btnVacante.UseVisualStyleBackColor = true;
            this.btnVacante.Click += new System.EventHandler(this.btnVacante_Click);
            // 
            // btnEntrevista
            // 
            this.btnEntrevista.Location = new System.Drawing.Point(13, 197);
            this.btnEntrevista.Name = "btnEntrevista";
            this.btnEntrevista.Size = new System.Drawing.Size(393, 99);
            this.btnEntrevista.TabIndex = 2;
            this.btnEntrevista.Text = "Entrevista";
            this.btnEntrevista.UseVisualStyleBackColor = true;
            this.btnEntrevista.Click += new System.EventHandler(this.btnEntrevista_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(418, 307);
            this.Controls.Add(this.btnEntrevista);
            this.Controls.Add(this.btnVacante);
            this.Controls.Add(this.btnProspecto);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Entrevista";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnProspecto;
        private System.Windows.Forms.Button btnVacante;
        private System.Windows.Forms.Button btnEntrevista;
    }
}

