﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace entrevista
{
    public partial class prospecto : Form
    {
        //Conexion a la base de datos
        SqlConnection con;

        void Conexion()
        {
            try
            {
                con = new SqlConnection(@"server=DESKTOP-75A4S5V\SQLEXPRESS ; database=master ; integrated security = true");

                con.Open();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Esto lo hice para generar los id automaticamente
        void prospectoid() { 
        string query = "SELECT id from prospecto";
        SqlCommand consultacmd = new SqlCommand(query, con);
        SqlDataReader leer;
        leer = consultacmd.ExecuteReader();
                try
                {
                    while (leer.Read())
                    {
                        label4.Text = leer["id"].ToString();

    }

}
                catch (SqlException ex)
            {
    MessageBox.Show("No se encontro nada. " + "Reporte este problema al correo: sistemas@orangexp.net "
        + ex.ToString());
            }

leer.Close();
}
        public prospecto()
        {
            InitializeComponent();

            Conexion();

            prospectoid();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //Primero se crean las validaciones para los campos
            //Los campos no pueden estar vacios
           
            
            if (txtNombre.Text == "")
            {
                MessageBox.Show("No se pueden dejar los campos vacios");
            }
            else if(txtCorreo.Text=="")
            {
                MessageBox.Show("No se pueden dejar los campos vacios");
            }
            else
            {
                string correo = txtCorreo.Text + "@" + Convert.ToString(cmbCorreo.SelectedItem);
                DateTime date = DateTime.Now;
                try
                {
                    string agregar = "INSERT INTO Prospecto (id, nombre, correo, fecha_registro) VALUES (@id, @Nombre, @Correo, @Fecha_registro)";
                    SqlCommand com = new SqlCommand(agregar, con);

                    com.Parameters.AddWithValue("@id", Convert.ToInt32(label4.Text)+1);
                    com.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                    com.Parameters.AddWithValue("@Correo", correo);
                    com.Parameters.AddWithValue("Fecha_registro", date);

                    com.ExecuteNonQuery();
                    MessageBox.Show("Se guardó correctamente");
                    prospectoid();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                
            }

            
           

        }

        //Para ver el reporte de los prospectos
        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string query = "SELECT * FROM prospecto";
                SqlCommand consultacmd = new SqlCommand(query, con);
                SqlDataAdapter adap = new SqlDataAdapter();
                adap.SelectCommand = consultacmd;
                DataTable dtable = new DataTable();
                adap.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }


    }
}
