﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace entrevista
{
    public partial class Entrevista : Form
    {
        //Se hace la conexion
        SqlConnection con;

        void Conexion()
        {

            try
            {
                con = new SqlConnection(@"server=DESKTOP-75A4S5V\SQLEXPRESS ; database=master ; integrated security = true");

                con.Open();

                try
                {
                    string query = "SELECT * FROM prospecto";
                    SqlCommand consultacmd = new SqlCommand(query, con);
                    SqlDataAdapter adap = new SqlDataAdapter();
                    adap.SelectCommand = consultacmd;
                    DataTable dtable = new DataTable();
                    adap.Fill(dtable);
                    dataGridView2.DataSource = dtable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());

                }

                try
                {
                    string query = "SELECT * FROM vacante";
                    SqlCommand consultacmd = new SqlCommand(query, con);
                    SqlDataAdapter adap = new SqlDataAdapter();
                    adap.SelectCommand = consultacmd;
                    DataTable dtable = new DataTable();
                    adap.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());

                }



            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        //Esto lo hice para generar los id automaticamente
        void entrevistaid()
        {
            string query = "SELECT id from entrevista";
            SqlCommand consultacmd = new SqlCommand(query, con);
            SqlDataReader leer;
            leer = consultacmd.ExecuteReader();
            try
            {
                while (leer.Read())
                {
                    label5.Text = leer["id"].ToString();

                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("No se encontro nada. " + "Reporte este problema al correo: sistemas@orangexp.net "
                    + ex.ToString());
            }

            leer.Close();
        }

       
        public Entrevista()
        {
            InitializeComponent();
            Conexion();

            entrevistaid();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            //Se valida que los campos no esten vacios
            if(txtNotas.Text=="" || txtProspecto.Text=="" || txtVacante.Text=="")
            {
                MessageBox.Show("No se puede dejar vacio este campo");
            }
            else
            {
                try
                {
                    DateTime date = DateTime.Now;

                    //Se insertan los valores en la tabla entrevista
                    string agregar = "INSERT INTO entrevista (id, vacante, prospecto, fecha_entrevista, notas, reclutado) VALUES (@id, @vacante, @prospecto,@fecha_entrevista, @notas, @reclutado)";
                    SqlCommand com = new SqlCommand(agregar, con);

                    com.Parameters.AddWithValue("@id", Convert.ToInt32(label5.Text) + 1);
                    com.Parameters.AddWithValue("@vacante", Convert.ToInt32(txtVacante.Text));
                    com.Parameters.AddWithValue("@prospecto", Convert.ToInt32(txtProspecto.Text));

                    com.Parameters.AddWithValue("@fecha_entrevista",date);
                    com.Parameters.AddWithValue("@notas", txtNotas.Text);
                    
                    if (ckAceptado.Checked == true)
                    {
                        com.Parameters.AddWithValue("@reclutado", true);
                    }
                    else
                    {
                        com.Parameters.AddWithValue("@reclutado", false);
                    }
                    com.ExecuteNonQuery();

                    

                    MessageBox.Show("Se guardó correctamente");
                   

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
        }

        //Se actualiza el reporte de vacantes
        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string query = "SELECT * FROM vacante";
                SqlCommand consultacmd = new SqlCommand(query, con);
                SqlDataAdapter adap = new SqlDataAdapter();
                adap.SelectCommand = consultacmd;
                DataTable dtable = new DataTable();
                adap.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }
        //Se actualiza el reporte de prospecto
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string query = "SELECT * FROM prospecto";
                SqlCommand consultacmd = new SqlCommand(query, con);
                SqlDataAdapter adap = new SqlDataAdapter();
                adap.SelectCommand = consultacmd;
                DataTable dtable = new DataTable();
                adap.Fill(dtable);
                dataGridView2.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtVacante.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtProspecto.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            reporteentrevistas reporte = new reporteentrevistas();
            reporte.Show();
        }
    }
}
