﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace entrevista
{
    public partial class Form1 : Form
    {
        SqlConnection con;

        void Conexion()
        {

            // Se hace la conexion con la base de datos
            try
            {
                con = new SqlConnection(@"server=DESKTOP-75A4S5V\SQLEXPRESS ; database=master ; integrated security = true");

                con.Open();
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }
        public Form1()
        {
            InitializeComponent();
            Conexion();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        //Este es el menu
        private void button1_Click_1(object sender, EventArgs e)
        {
            prospecto prospecto = new prospecto();
            prospecto.Show();
        }

        private void btnVacante_Click(object sender, EventArgs e)
        {
            vacante vacante = new vacante();
            vacante.Show();
        }

        private void btnEntrevista_Click(object sender, EventArgs e)
        {
            Entrevista entrevista = new Entrevista();
            entrevista.Show();
        }
    }
}
